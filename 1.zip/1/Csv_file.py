# csv file

# import pandas as pd

# df =pd.read_csv('1.csv')
# print(df)

#xl file

# import pandas as pd
# import xlrd
# import openpyxl

# data = pd.read_excel('1.xlsx')
# print(data)


#dictionary

# stud={'rollno':[1,2,3],'name':['acf','ase','dwa']}

# import pandas as pd

# dic = pd.DataFrame(stud)

# print(dic)

#tuple

# stud = [(1,'abc','a'),(1,'abc','a'),(1,'abc','a')]

# import pandas as pd

# data = pd.DataFrame(stud)

# # print(stud)

# print(data.shape)
# print(data.head()) #give arg in bracket
# print(data.tail()) #give arg in bracket