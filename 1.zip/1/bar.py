import pandas as pd
import matplotlib.pyplot as plt
import openpyxl
import xlrd

# df = pd.read_excel('1.xlsx')
# print(df)

# x = df['id']
# y = df['name']

# plt.bar(x,y,label='Total_Sales',color='Blue')

# plt.xlabel = ('Types Of Books')
# plt.ylabel = ('Sales')

# plt.title =("Book  Stall")

# plt.legend()

# plt.show()

x = [101,108,112]
y = [1100,1200,1300]


x1 = [101,108,112]
y1 = [1100,1200,1300]

plt.bar(x,y,label='Total_Sales',color='Blue')

plt.bar(x1,y1,label='Total_Sales',color='Blue')

plt.xlabel = ('Types Of Books')
plt.ylabel = ('Sales')

plt.legend()

plt.show()