import mysql.connector

mydb= mysql.connector.connect(host = 'localhost',
                              user = 'root',
                              password='',
                              database='student')

mycursor = mydb.cursor()
# q='create database  if not exists student'
# mycursor.execute(q)

# print("DataBase  created...")

# tab_q = "create table stud(id int(2) primary key auto_increment, name varchar(50), city varchar(50))"

# mycursor.execute(tab_q)

# in_q = "insert into stud(name,city) values(%s,%s)"
# rec = [('abc','brs')]

# mycursor.executemany(in_q,rec)
# mydb.commit()
# print("Data Inserted...")

# sel_q = "select * from stud"
# mycursor.execute(sel_q)
# result = mycursor.fetchall()
# for i in result:
#      print(i)     

# up = "update stud set name= %s where id=%s"
# val = ('xyz',2)
 
# mycursor.execute(up, val)
# mydb.commit()

# dlt = "delete from stud where id=2"

# mycursor.execute(dlt)
# mydb.commit()