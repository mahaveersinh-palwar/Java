import mysql.connector

mydb = mysql.connector.connect(host='localhost',
                               user='root',
                               password='',
                               database='student')

# print (mydb)
mycursor = mydb.cursor()

choice = 0
while choice != 5:
    print("1. Add student")
    print("2. Show student")
    print("3. Update student")
    print("4. Delete student")
    print("5. Exit")
    
    choice = int(input("Enter your choice:"))
    
    if choice == 1:
        q = "insert into stud(name,city) values(%s,%s)"
        val = [('jsd','sdw'),('dww','dww'),('dqq','kdl')]
        
        mycursor.executemany(q,val)
        mydb.commit()
        print("Data Inserted...")
        
    elif choice == 2:
        qry = "select * from stud"
        mycursor.execute(qry)
        data = mycursor.fetchall()
        
        for i in data:
            print(i)
            
    elif choice == 3:
        id = input("Enter the ID of student :")
        name = input("Enter new Name :")
        city = input("Enter New City :")
        
        qry = "update stud set name=%s,city=%s where id=%s"
        val = (name,city,id)
        
        mycursor.execute(qry,val)
        mydb.commit()
        print("Data Updated..")
        
    elif choice == 4:
        id = input("Enter Student Id to delete : ")
        
        qry = "delete from stud where id=4"
        
        mycursor.execute(qry)
        mydb.commit()
        print("Data Deleted...")
        
        
    
    


