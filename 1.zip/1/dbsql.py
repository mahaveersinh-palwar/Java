import sqlite3

cnt = sqlite3.connect('mydb.dp')

# q = "create table stud1(id integer , name varchar)"

# cnt.execute(q)
# print("Table Created...")

# inst = """ insert into stud1(id, name) values(1,'ada'),(2,'xsa'),(3,'sxs') """

# cnt.execute(inst)
# cnt.commit()
# print("Record Insert Successfully...")

# slt = "select * from stud1"

# data = cnt.execute(slt)

# for i in data:
#     print(i)

# up = """update stud1 set name = "Veersinh" where id = 2 """

# cnt.execute(up)

# data = cnt.execute("select * from stud1")

# for i in data:
#     print(i)

dlt = """delete from stud1 where id=2"""

cnt.execute(dlt)

data = cnt.execute("select * from stud1")

for i in data:
    print(i)